var theme_config = {
	//导航标题
	nav_title: 'Eltrac\'s Note',
}